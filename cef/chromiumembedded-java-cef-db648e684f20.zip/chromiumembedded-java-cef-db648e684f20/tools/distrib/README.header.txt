Java Chromium Embedded Framework (JCEF) Binary Distribution for $PLATFORM$
-------------------------------------------------------------------------------

Date:             $DATE$

JCEF Version:     $JCEF_VER$
JCEF URL:         $JCEF_URL$
                  @$JCEF_REV$

CEF Version:      $CEF_VER$
CEF URL:          $CEF_URL$

Chromium Verison: $CHROMIUM_VER$
Chromium URL:     $CHROMIUM_URL$

This distribution contains all components necessary to build and distribute a
Java application using JCEF on the $PLATFORM$ platform. Please see the LICENSING
section of this document for licensing terms and conditions.
