#!/bin/sh
python tools/fix_style.py $@
